package WEEKEND2;

public class Owl extends Birds {
	int let;
	int loc;
	
	
	

	public void hunts() {
		System.out.println("Owl hunts other Owls");
	}
	
	
		
		
	public Owl(int let, int loc, String color, String food, String gender, String name, int nol) {
		// TODO Auto-generated constructor stub
		this.let=let;
		this.loc=loc;
		 
			this.color=color;
			this.food=food;
			this.gender=gender;
			this.name=name;
			this.nol=nol;
	}


	public void display() {
		System.out.println(" Name: "+this.name+" No of legs: " +this.nol + " Skin color: "+ this.color + " Food: " + this.food   
							+ " Gender: " + this.gender + " Age: "  );
		
		System.out.println(" Length of teeth : "+ this.let + " Length of claws : " + this.loc);
	}

}

