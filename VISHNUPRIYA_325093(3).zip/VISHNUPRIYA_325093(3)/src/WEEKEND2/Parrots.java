package WEEKEND2;

public class Parrots extends Birds{
	int lob;
	int wob;
	
	public void imitate() {
		System.out.println("Parrot imitate sounds ");
	}
	

	public void screams() {
		System.out.println("Parrot scream noise");
	}
	
	
		
	public Parrots(int lob, int wob, int age, String color, String food, String gender, String name, int nol) {
		// TODO Auto-generated constructor stub
		this.lob=lob;
		this.wob=wob;
	    
		this.color=color;
		this.food=food;
		this.gender=gender;
		this.name=name;
		this.nol=nol;
	}


	public void display() {
		System.out.println(" Name: "+this.name +" No of legs: " +this.nol + " Skin color: "+ this.color + " Food: " + this.food 
							+ " Gender: " + this.gender );
		
		System.out.println(" Length of beak : "+ this.lob + " weight of parrot: " + this.wob);
	}
}
