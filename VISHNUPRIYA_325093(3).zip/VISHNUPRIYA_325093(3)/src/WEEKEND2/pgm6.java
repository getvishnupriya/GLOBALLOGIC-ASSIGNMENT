package WEEKEND2;

public class pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Parrots p1 = new Parrots(5,10,80,"Red","fruits","male","appu",2);
		Parrots p2 = new Parrots(6,4,40,"Yellow","seeds","female","ammu",2);
		Parrots p3 = new Parrots(8,12,20,"Bluish","insects","female","maakri",2);
		Owl o1 = new Owl(40,620,"White","squirrels","male","manu",2);
		Owl o2= new Owl(70,2000,"Black","insects","male","jaan",2);
		
		p1.display();
		p1.eats();
		p1.flys();
		
		p2.display();
		p2.imitate();
		p2.flys();
		
		p3.display();
		p3.eats();
		p3.screams();
		
		o1.display();
		o1.eats();
		
		o2.display();
		o2.hunts();
		
		

	}

}

