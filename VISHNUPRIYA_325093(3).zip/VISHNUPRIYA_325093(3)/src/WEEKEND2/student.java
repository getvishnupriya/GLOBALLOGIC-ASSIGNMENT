package WEEKEND2;

public class student {
	int rollno;
	String name;
	int java;
	int selenium;
	float avg;
	public float average()
	{
		this.avg= (float)((this.java+this.selenium)/2);
		return this.avg;
	}
	
	
	

	public student(int rollno, String name, int java, int selenium) {
		
		this.rollno = rollno;
		this.name = name;
		this.java = java;
		this.selenium = selenium;
		
	
	}
	




	public static void main(String[] args) {
		// TODO Auto-generated method stub
		student s1=new student(1,"aaa",30,50);
		student s2=new student(1,"bbb",60,80);
		student s3=new student(1,"aaa",90,85);
		if(s1.average()>65)
		{
			System.out.println(s1.average());
		}
		if(s2.average()>65)
		{
			System.out.println(s2.average());
		}
		if(s3.average()>65)
		{
			System.out.println(s3.average());
		}
		
		
		
		
		
		
		
		
	}

}
