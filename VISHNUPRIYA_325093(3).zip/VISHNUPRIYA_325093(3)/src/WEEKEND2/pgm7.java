package WEEKEND2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import DAY3.student;

public class pgm7 {
	public ArrayList<product> read_excel()
	{
		
		ArrayList<product> pd_al=new ArrayList<product>();
		
		
		for(int i=1;i<4;i++)
		{
			product p=new product();
		try {
			File f=new File("C:\\Users\\vishnupriya.jayaraj\\Desktop\\weekend.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("sheet1");
			XSSFRow r=sh.getRow(i);
			
			XSSFCell c=r.getCell(0);
			p.pro_id=(int) c.getNumericCellValue();
			
			XSSFCell c1=r.getCell(1);
			p.Name= c1.getStringCellValue();
			
			XSSFCell c2=r.getCell(2);
			p.u_pur=(int) c2.getNumericCellValue();
			
			XSSFCell c3=r.getCell(3);
			p.U_rate=(int) c3.getNumericCellValue();
			
			
			
			p.price();
			p.grade(p);
			pd_al.add(p);
		} 
		catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) 
		{
			
			e.printStackTrace();
		}
	

	}
		return pd_al;
	}
	
	public void write_excel(ArrayList<product> al_pd1)
	
	{
		int row=1;
	
		try {
			File f=new File("C:\\Users\\vishnupriya.jayaraj\\Desktop\\weekend.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("sheet1");
		for(product p:al_pd1)
		{
			XSSFRow r=sh.getRow(row);
			XSSFCell c=r.createCell(4);
			c.setCellValue((double) p.price);
			XSSFCell c1=r.createCell(5);
			c1.setCellValue(p.grade);
			FileOutputStream fos= new FileOutputStream(f);
			wb.write(fos);			row++;
		
		
			
		}
		
		}
			 catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	}
	
	

}
