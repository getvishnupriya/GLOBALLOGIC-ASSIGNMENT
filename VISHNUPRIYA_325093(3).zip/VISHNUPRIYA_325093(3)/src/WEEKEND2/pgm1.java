package WEEKEND2;

import java.util.ArrayList;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> arr=new ArrayList<Integer>();
		for(int i=10;i<=30;i++)
		{
			if(i%2==0)
			{
				arr.add(i);
				
			}
		}
		System.out.println(arr);
		

	}

}
