package DAY4;

public class student {
	 int rollno;
	 String name;
	 int m1;
	int m2;
	 float avg;
	 void display()
	{
		System.out.println("Name:"+name+"\n"+"Rollno:"+rollno);
	}
 

	public student(int rollno, String name,int m1) {
		// TODO Auto-generated constructor stub
		this.rollno=rollno;
		this.name=name;
		this.m1=m1;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		student s1=new student(10,"rakesh",855);
		s1.display();
		
		
	}

}
