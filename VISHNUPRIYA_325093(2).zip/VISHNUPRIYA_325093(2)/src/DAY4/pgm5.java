package DAY4;

public class pgm5 {
	
	public int add(int x,int y){
		int z=x+y;
		return z;
	}
	public float add(int x,int y,float f){
		float z=x+y+f;
		return z;

}
}
