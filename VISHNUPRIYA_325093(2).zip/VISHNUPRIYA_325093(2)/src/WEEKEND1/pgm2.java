package WEEKEND1;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a1= new int[20];
		int[] a2 = new int[20];
		int c=0,d=0;
		for(int i=10;i<=30;i++)
		{
			if(i%3==0)
			{
				a1[c]=i;
				c++;
				
			}
			
		}
//		for(int p=0;p<c;p++)
//		{
//			System.out.println(a1[p]);
//		}
		for(int j=10;j<=30;j++)
		{
			if(j%5==0)
			{
				a2[d]=j;
				d++;
			}
			
			
		}
//		for(int m=0;m<d;m++)
//		{
//			System.out.println(a2[m]);
//		}
		System.out.println("First array\tSecond array\tsum");
		for(int k=0;k<c;k++) 
		{
			for(int z=0;z<=d;z++)
			{
				int sum=a1[k]+a2[z];
				if(sum>30&&sum<40)
				{
					System.out.println(a1[k]+"\t\t"+a2[z]+"\t\t"+sum);
				}
			}
			
		}
		
	
		

	}

}
