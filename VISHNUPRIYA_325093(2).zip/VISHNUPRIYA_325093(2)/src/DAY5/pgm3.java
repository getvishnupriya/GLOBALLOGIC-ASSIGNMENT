package DAY5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class pgm3 {

	//private static final String FileOutputStream fos = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			File f=new File("C:\\Users\\vishnupriya.jayaraj\\Desktop\\sample.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("sheet1");
			//XSSFRow r=sh.getRow(0);
			//XSSFCell c=r.getCell(0);
			//XSSFCell c=r.createCell(1);
			XSSFRow r=sh.createRow(3);
			XSSFCell c=r.createCell(1);
			
			String s=c.getStringCellValue();
			System.out.println(s);
			
			//writing to a file
			c.setCellValue("selenium");
			FileOutputStream fos= new FileOutputStream(f);
			wb.write(fos);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
