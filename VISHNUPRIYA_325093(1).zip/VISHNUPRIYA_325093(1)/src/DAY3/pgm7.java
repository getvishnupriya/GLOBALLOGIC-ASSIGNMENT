package DAY3;

public class pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String s1="noida",s2="Noida",s3="noida",s4="I am Learning Java";
		 int l;
		 l=s1.length();
		 System.out.println("length of s1 is"+l);
		 int p=s1.compareTo(s2);
		 System.out.println(p);
		 int p1=s1.compareToIgnoreCase(s2);
		 System.out.println(p1);
		 String s=s4.substring(0, 3);
		 System.out.println(s);
		 int a=s4.indexOf("a");
		 System.out.println(a);
		 int b=s4.indexOf("a", 3);
		 System.out.println(b);
		 
	}

}
