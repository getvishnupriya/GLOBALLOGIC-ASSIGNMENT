package DAY3;

public class pgm8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="  I am Learning java";
		int c=0,p=0;
		
		while(p!=-1) {
			p=s.indexOf(" ",p);
			
			if(p==-1)
				break;
			
			c++;
			p++;
			
			
			
		}
		System.out.println(c);
	}

}
