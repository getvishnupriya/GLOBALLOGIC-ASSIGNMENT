package DAY3;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,m=1;
		int marks[][]= {{66,77,88,99},{43,67,89,60},{12,11,34,46}};
		int row[]= {0,0,0,0};
		for( i=0;i<3;i++)
		{
			for(j=0;j<4;j++)
			{
				System.out.print(marks[i][j]+" ");
			}
			System.out.println();
			
			
		}
		for(i=0;i<3;i++)
		{
		 int c=0;
		for(j=0;j<4;j++){
			row[c]=marks[i][j];
			c++;
			
		}
		
		max(row,m );
		m++;
	}
	}



	public static void max(int row[],int m)
	{	int i;
		int largest=row[0];
		for(i=0;i<4;i++)
		{
			if(largest<row[i])
			{
				largest=row[i];
			}
			
		}
		System.out.println("Row"+m+":"+largest);
	}

}
