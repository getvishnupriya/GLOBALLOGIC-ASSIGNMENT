package DAY1;
import java.util.Scanner; 

public class pgm12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 Scanner myObj = new Scanner(System.in);  
		 
		 System.out.println("Enter mark1");
		 int mark1 = myObj.nextInt();  
		
		 System.out.println("Enter mark2");
		 int mark2 = myObj.nextInt();
		
		 System.out.println("Enter mark3");
		 int mark3 = myObj.nextInt();
		    
		 double avg=((mark1+mark2+mark3)/3);
		 if(avg>=60)
			 System.out.println("first class");
		 else if(avg>=50 && avg<60)
			 System.out.println("second class");
		 else if(avg>=35 && avg<=50)
			 System.out.println("pass class");
		 else
			 System.out.println("fail");
	}

}
