package BASE_CLASSES;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class excel_op {

	static keyword_sh key;
	static tc_selection tc;
	
	
	
	public static  tc_selection get_next_testcase_ID(int i)
	{
		tc=new tc_selection();
		
		try {
			File f=new File("POC.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("TC_SELECTION_SHEET");
			//System.out.println(i);
			XSSFRow r=sh.getRow(i);
			XSSFCell c=r.getCell(0);
			tc.tcid=c.getStringCellValue();
			XSSFCell c1=r.getCell(1);
			tc.flag=c1.getStringCellValue();
			XSSFCell c2=r.getCell(2);
			tc.no_steps=(int) c2.getNumericCellValue();
			
			
			wb.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tc;
	}
	
	public static keyword_sh search_testcase(int j) {
		// TODO Auto-generated method stub
		
		key=new keyword_sh();
		

		try {
			File f=new  File("POC.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("KEYWORD");
			XSSFRow r=sh.getRow(j);
			XSSFCell c=r.getCell(0);
			key.TC_ID=c.getStringCellValue();
			XSSFCell c1=r.getCell(1);
			key.step_no=(int) c1.getNumericCellValue();
			XSSFCell c2=r.getCell(2);
			key.KeyWord=c2.getStringCellValue();
			XSSFCell c3=r.getCell(3);
			key.Xpath=c3.getStringCellValue();
			XSSFCell c4=r.getCell(4);
			key.Test_data=c4.getStringCellValue();
			
			wb.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return key;
			}
	
	public static void write_excel(int row,String s)
	{
		File f=new  File("POC.xlsx");
		FileInputStream fis;
		try {
			fis = new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("TC_SELECTION_SHEET");
				XSSFRow r=sh.getRow(row);
				XSSFCell c=r.createCell(3);
				c.setCellValue(s);
				FileOutputStream fos=new FileOutputStream(f);
				wb.write(fos);
				
				wb.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
}
