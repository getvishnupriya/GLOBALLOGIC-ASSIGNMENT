package BASE_CLASSES;


public class driver_method extends all_driver_methods{

	public static tc_selection tc;
	public static keyword_sh key;
	public static void testcase_executor()
	{
		int i,j;
	for(i=1;i<=4;i++)
	{
		tc=new tc_selection();
		
		tc=get_next_testcase_ID(i);
		if(tc.flag.equals("Y"))
		{
			for(j=1;j<=19;j++) 
			{
				key=new keyword_sh();
				key= search_testcase(j);
				if(tc.tcid.equals(key.TC_ID)) {
					
					
					switch(key.KeyWord)
					{
					case "launchbrowser":
						launchchrome(key.Xpath);
						break;
					
					case "entertext":
						entertxt(key.Xpath,key.Test_data);
						break;
					case"clickbutton":
						click_btn(key.Xpath);
						break;
					case "link":
						
					case "verify":
					 verify(key.Xpath,key.Test_data,i);
					
						break;
					case "log":
						log(ac_res,key.Test_data,t_res);
						break;
						
					
					}
					
					
				}
			
				
				
				
			}
		}
		else
		{
			
			
			continue;
			
			
			
		}
		
	}
	
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		
		testcase_executor();
		
		
		
		//System.out.println("asdf");
		

	}

}
