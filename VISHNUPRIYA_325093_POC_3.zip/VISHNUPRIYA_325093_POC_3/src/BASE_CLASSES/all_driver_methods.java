package BASE_CLASSES;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class all_driver_methods extends excel_op {
	static WebDriver dr;
	static WebDriverWait drw;
	static WebElement we;
	
	static String ac_res;
	static String ex_res;
	static String t_res;
	

	
	public static void launchchrome(String url)
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		dr=new ChromeDriver();              
		dr.get(url);
		
	}
	
	public static void entertxt(String xpath, String data)
	{
		dr.findElement(By.xpath(xpath)).sendKeys(data);
	}
	
	public static void click_btn(String xpath)
	{
		dr.findElement(By.xpath(xpath)).click();
	}
	
	
	public static String verify(String xpath,String data,int row)
	{
		drw=new WebDriverWait(dr,20);
		we=drw.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
		ac_res=dr.findElement(By.xpath(xpath)).getText();
		ex_res=data;
		if(ac_res.equals(ex_res))
		{
			write_excel(row,"pass");
			t_res="pass";
			
		}
			else
			{
			write_excel(row,"fail");
			t_res="fail";
			
			}
		return ac_res;
		
		}
	
	public static void log(String ac_res,String data,String t_res) {
		
		Logger log=Logger.getLogger("devpinoyLogger");
		log.debug("ac_res="+ac_res +"\t"+"ex_res=" +data +"\t"+"test res= "+t_res);
		
		
		
	}
	
	
	
	
	}

	


