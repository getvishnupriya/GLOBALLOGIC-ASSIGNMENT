package DAY9;

public class HDFC extends pgm2{
	
	public float get_roi()
	{
		return 8.5f;
		
	}
}
