package DAY9;

public class main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pgm2 ob;
		ob=new ICICI();
		System.out.println("ICICI ROI :"+ob.get_roi());
		
		ob=new HDFC();
		System.out.println("ICICI ROI :"+ob.get_roi());
		

	}

}
