package DAY9;

public class ICICI extends pgm2{
	public float get_roi()
	{
		return 9.5f;
		
	}

}
