package DAY9;

public class pgm1 {
	private int acc_no;
	private int acc_bal;
	public int getacc_no() {
		return acc_no;
	}
	public void setacc_no(int acc_no) {
		this.acc_no = acc_no;
	}
	public int getacc_bal() {
		return acc_bal;
	}
	public void setacc_bal(int acc_bal) {
		this.acc_bal = acc_bal;
	}
	

}
