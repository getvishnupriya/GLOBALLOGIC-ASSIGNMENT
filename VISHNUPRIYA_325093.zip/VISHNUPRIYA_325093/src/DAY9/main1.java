package DAY9;

public class main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pgm1 ob=new pgm1();
		ob.setacc_bal(10001);
		ob.setacc_no(123455678);
		System.out.println("account no is:"+ob.getacc_no());
		System.out.println("account balance is :"+ ob.getacc_bal());
	}

}
