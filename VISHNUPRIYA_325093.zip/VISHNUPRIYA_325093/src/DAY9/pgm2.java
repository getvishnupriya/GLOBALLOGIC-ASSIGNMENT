package DAY9;

public class pgm2 {
	
	public float get_roi()
	{
		return 0f;
		
	}
	public void show() {
		System.out.println("Bank Details");
	}

}
