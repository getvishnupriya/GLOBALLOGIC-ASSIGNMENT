package DAY8;



public class Travel {

	
		public int sl_no;
		public String Name;
		public String From;
		public String To;
		public int Rate;
		public int seats;
		public long tot;
		public  void total()
		{
			 this.tot=this.Rate*this.seats;
		

		}
		
	public Travel() {
		
	}
		
		public Travel(int sl_no,String Name,String From,String To,int Rate,int seats)
		{
			this.sl_no=sl_no;
			this.Name=Name;
			this.From=From;
			this.To=To;
			this.Rate=Rate;
			this.seats=seats;
			this.total();
			
		}

}
