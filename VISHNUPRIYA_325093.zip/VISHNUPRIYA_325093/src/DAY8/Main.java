package DAY8;

import java.util.ArrayList;


public class Main {
// TODO Auto-generated method stub
		public static void main(String[] args) {
			
			Passenger p=new Passenger();
			
			ArrayList<Travel> s=new ArrayList<Travel>();
			
			 s=p.read_excel();
				
				p.write_excel(s);
			
		}
}
