package WEEKEND2;

public class parrot extends bird {
	int lob;              //length of beak
	String color;
	 public void imitates()
	 {
		 System.out.println("parrot imitates like human beings");
	 }
	 public void eats()
	 {
		 System.out.println("parrot eats fruits,flowers,buds,nuts,seeds,and some small insects");
		 
	 }
	 public void founds()
	 {
		 System.out.println("parrots are found in Australia,Ceentral america,South America");
		 
	 }
	 public void display()
		{
			System.out.println("no:of legs"+this.nol+"no:of wings"+this.now+"length of beak"+lob+"color of parrot is "+this.color);
		}
	 
	

}
