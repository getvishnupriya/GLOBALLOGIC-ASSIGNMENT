package WEEKEND2;

public class test_bird {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 parrot p1=new parrot();
		 parrot p2=new parrot();
		 parrot p3=new parrot();
		 owls o1=new owls();
		 owls o2=new owls();
		 
		 p1.nol=2;
		 p1.now=2;
		 p1.lob=2;
		 p1.color="green";
		 p1.eats();
		 p1.flys();
		 p1.founds();
		 p1.display();
		 
		 p2.nol=2;
		 p2.now=2;
		 p2.lob=3;
		 p2.color="yellow";
		 p2.eats();
		 p2.flys();
		 p2.founds();
		 p2.display();
		 
		 
		 p3.nol=2;
		 p3.now=2;
		 p3.lob=1;
		 p3.color="mixed";
		 p3.eats();
		 p3.flys();
		 p3.founds();
		 p3.display();
		 
		 
		 o1.nol=2;
		 o1.now=2;
		 o1.soe=2;
		 o1.species="mammal";
		 o1.eats();
		 o1.founds();
		 o1.sounds();
		 o1.display();
		 
		 o2.nol=2;
		 o2.now=2;
		 o2.soe=2;
		 o2.species="mammal";
		 o2.sounds();
		 o2.eats();
		 o2.founds();
		 o2.display();
		 
		 
		 
		 
	}

}
