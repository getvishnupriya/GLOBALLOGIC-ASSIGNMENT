package WEEKEND2;

public class product {
	int pro_id;
	String Name;
	int U_rate;
	int u_pur;
	int price;
	String grade;
	
	public void price()
	{
		this.price=U_rate*u_pur;
		
		
	}
	public void grade(product p)
	{
		if(p.price<25000)
		{
			this.grade="Grade A";
		}
		if(p.price>=25000)
		{
			this.grade="Grade B";
		}
		
	}

}
