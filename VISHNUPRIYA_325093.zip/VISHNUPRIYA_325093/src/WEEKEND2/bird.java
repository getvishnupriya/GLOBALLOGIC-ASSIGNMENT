package WEEKEND2;

public class bird {
	int nol;
	int now;
	
	
	
	
	public void flys()
	{
		System.out.println("birds flys");
	}
	public void display()
	{
		System.out.println("no:of legs"+this.nol+"no:of wings"+this.now);
	}

}
