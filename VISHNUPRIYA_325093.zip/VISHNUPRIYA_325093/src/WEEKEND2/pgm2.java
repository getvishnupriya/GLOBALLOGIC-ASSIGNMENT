package WEEKEND2;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number=1,s=0,c=0,d,q;
		int n=number;
		while(c<5)
		{
			while(n>0) {
				
			
			d=n%10;
			q=d*d*d;
			s=s+q;
			n=n/10;
			}
			
			
				if(s==number)
				{
					System.out.println(s+"\n");
					c++;
					
				}
				
			number++;
			n=number;
			s=0;
				
			
			
			
			
		}

	}

}
