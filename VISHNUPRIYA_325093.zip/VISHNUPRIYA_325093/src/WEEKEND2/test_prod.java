package WEEKEND2;

import java.util.ArrayList;



public class test_prod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pgm7 ob=new pgm7();
		ArrayList<product> s=new ArrayList<product>();
		
		 s=ob.read_excel();
			
			ob.write_excel(s);

	}

}
