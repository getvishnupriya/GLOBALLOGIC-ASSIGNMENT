package WEEKEND2;

import java.util.ArrayList;


public class pgm5 {
	ArrayList<String> arr_out=new ArrayList<String>();
	String arr1[];
	
	
	public ArrayList<String> get_each_word(String str)
	{
		ArrayList<String> s=new ArrayList<String>();
		arr1=str.split(" ");
		//System.out.println(arr1);
		for(String s1:arr1)
		{
			s.add(s1);
		}
		//System.out.println(arr);
		return s;
	}
	public ArrayList<String> count_vowels(ArrayList<String> s)
	{	
		
		
		for(int i=0;i<s.size();i++)
		{	int c=0;
			String word=s.get(i);
			for(int j=0;j<word.length();j++)
			{
				if(word.charAt(j)=='a'|| word.charAt(j)=='e'|| word.charAt(j)=='i'|| word.charAt(j)=='o'|| word.charAt(j)=='u'|| word.charAt(j)=='A'|| word.charAt(j)=='E'|| word.charAt(j)=='I'||word.charAt(j)=='O'|| word.charAt(j)=='U' )  
				{
					c++;
				}
				if( c>=3)
				{
					arr_out.add(word);
					break;
					
				}
				
			}
			
			
			
			
		}
		return arr_out;
		
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="I have learnt loops, opps concepts, inheritance, exception handling, arraylist and string handling";
		String arr1[];
		pgm5 o=new pgm5();
		ArrayList<String> s=new ArrayList<String>();
		
		
		
		 s=o.get_each_word(str);
		 ArrayList<String> arr_out=o.count_vowels(s);
		 System.out.println(arr_out);

	}

}
