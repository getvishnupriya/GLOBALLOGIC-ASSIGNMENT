package WEEKEND2;

public class owls extends bird {
	int soe; //size of eyes
	String species;
	
	public void sounds()
	{
		System.out.println("owls make quiet sound");
	}
	public void sights()
	{
		System.out.println("have deep sight");
	}
	public void display()
	{
		System.out.println("no:of legs"+this.nol+"no:of wings"+this.now
				+"sice of eyes"+this.soe+"species is"+this.species);
	}
	public void eats() {
		// TODO Auto-generated method stub
		System.out.println("eats insects");
		
	}
	public void founds() {
		// TODO Auto-generated method stub
		System.out.println("remote eyelands");
		
	}

}
