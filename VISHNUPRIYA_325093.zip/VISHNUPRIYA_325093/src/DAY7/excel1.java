package DAY7;

import java.util.ArrayList;

import DAY3.student;
import DAY5.operations;

public class excel1 {


		// TODO Auto-generated method stub
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			//int r1=1;
			operations1 op=new operations1();
			//student s1=r.read_excel();
			ArrayList<student> s=new ArrayList<student>();
			
			 s=op.read_excel();
				
				op.write_excel(s);
			
			
			
				
			
			
			//write w=new write();
			
			
			
		}

	


	}


