package DAY7;


	import java.io.File;
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.io.FileOutputStream;
	import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
	import org.apache.poi.xssf.usermodel.XSSFRow;
	import org.apache.poi.xssf.usermodel.XSSFSheet;
	import org.apache.poi.xssf.usermodel.XSSFWorkbook;

	import DAY3.student;



	public class operations1{
		public ArrayList<student> read_excel()
		{
			
			ArrayList<student> std_al=new ArrayList<student>();
			
			
			for(int i=1;i<=2;i++)
			{student s=new student();
			try {
				File f=new File("C:\\Users\\vishnupriya.jayaraj\\Desktop\\Assignment.xlsx");
				FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("sheet1");
				XSSFRow r=sh.getRow(i);
				
				XSSFCell c=r.getCell(0);
				s.rollno=(int) c.getNumericCellValue();
				
				XSSFCell c1=r.getCell(1);
				s.name= c1.getStringCellValue();
				
				XSSFCell c2=r.getCell(2);
				s.m1=(int) c2.getNumericCellValue();
				
				XSSFCell c3=r.getCell(3);
				s.m2=(int) c3.getNumericCellValue();
				
				s.average();
				std_al.add(s);
			} 
			catch (FileNotFoundException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		

		}
			return std_al;
		}
		public void write_excel(ArrayList<student> al_std1)
		
		{
			int row=1;
		
			try {
				File f=new File("C:\\Users\\vishnupriya.jayaraj\\Desktop\\Assignment.xlsx");
				FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("sheet1");
			for(student s1:al_std1)
			{
				XSSFRow r=sh.getRow(row);
				XSSFCell c=r.createCell(4);
				c.setCellValue((double) s1.avg);
				row++;
			
			}
				FileOutputStream fos= new FileOutputStream(f);
				wb.write(fos);
				
			
			}
				 catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		}

	}
	
		


