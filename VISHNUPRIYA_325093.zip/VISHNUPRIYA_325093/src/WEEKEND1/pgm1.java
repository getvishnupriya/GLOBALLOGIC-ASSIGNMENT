package WEEKEND1;

public class pgm1 {
	String line="Hello I am working at Global Logic";
	
	
	public String[] extract_word(String str)
	{
		String words[]=line.split(" ");
		return words;
	}
	public void count_print()
	{
		String words[]=extract_word(line);
		for(int i=0;i<words.length;i++)
		{
			String word=words[i];
			if(word.length()>5)
			{
				System.out.println(words[i]);
			}
			
		}
	}

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		pgm1 s=new pgm1();
		s.count_print();

	}

}
