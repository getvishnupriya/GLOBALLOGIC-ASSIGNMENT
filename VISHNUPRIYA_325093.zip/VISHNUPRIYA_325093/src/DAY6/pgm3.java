package DAY6;

import java.util.ArrayList;



public class pgm3 {
	
	ArrayList<student> std_al=new ArrayList<student>();
	public void create_al()
	{
		student s1=new student("Ramesh",101,80,80);
		student s2=new student("Ramesh1",102,85,95);
		s1.average();
		s2.average();
		std_al.add(s1);
		std_al.add(s2);
		
	}
	public void display_al()
	{
		for(student s: std_al)
		{
			System.out.println("Name :"+s.name
					          +"Rollno:"+s.rollno
					          +"Mark1:"+s.m1
					          +"mark 2 :"+s.m2
					          +"average :"+s.avg);
					          
		}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pgm3 ob=new pgm3();
		ob.create_al();
		ob.display_al();

	}

}
