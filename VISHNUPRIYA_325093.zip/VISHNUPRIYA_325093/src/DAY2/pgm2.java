package DAY2;
import java.util.Scanner;
public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int s=9;
		switch(s)
		{
		case 0:
			System.out.println("zero");
			break;
		case 1:
			System.out.println("one");
			break;
		case 2:
			System.out.println("two");
			break;
		case 3:
			System.out.println("three");
			break;
		case 4:
			System.out.println("four");
			break;
		case 5:
			System.out.println("five");
			break;
		case 6:
			System.out.println("six");
			break;
		case 7:
			System.out.println("seven");
			break;
		case 8:
			System.out.println("eight");
			break;
		case 9:
			System.out.println("nine");
			
		default:
			System.out.println("no match");
		}
		System.out.println("out of switch");

	}

}
