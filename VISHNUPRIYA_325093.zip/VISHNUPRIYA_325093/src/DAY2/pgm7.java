package DAY2;

import java.util.Scanner;

public class pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int rem,sum=0;
		Scanner myObj = new Scanner(System.in);
		System.out.println("Enter a number");
		int num = myObj.nextInt();
		while(num>0)
		{
			
		rem=num%10;
		if(rem>5)
		{
			sum=sum+rem;
		
		}
		num=num/10;
		}
		System.out.println("sum is"+sum);
	}

}
