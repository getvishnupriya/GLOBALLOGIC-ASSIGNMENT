package DAY2;

public class pgm5 {
	public static void main(String[] args) {
	
	int i,j,count=0,k;
	for(i=6;i>0;i--)
	{
		for(j=i;j>=0;j--)
		{
			System.out.print(" ");
		}
		for(k=1;k<count;k++)
		{
			System.out.print(k);
		}
		count++;
		System.out.println("\n");
	}
}
}