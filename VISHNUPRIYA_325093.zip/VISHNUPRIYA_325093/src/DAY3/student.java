package DAY3;

public class student {
	int rollno;
	String name;
	int m1;
	int m2;
	float avg;
	public void average()
	{
		avg=(float)((m1+m2)/2.0);
	}
}
