package DAY3;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num[]= {21,34,91,59,16,25,29,74,49,82};
		int sum=0;
		for(int i=0;i<10;i++)
		{
			
			 if( isEven(num[i])==true)
			 {
				 sum=sum+num[i];
			 }
		}
		
		System.out.println(sum);
		
	}
	public static boolean isEven(int num)
	{	
		
			if(num%2==0)
			{
				
				return true;
			}
			return false;
			
		
	
		
	}

}
