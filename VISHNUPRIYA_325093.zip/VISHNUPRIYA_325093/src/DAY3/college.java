package DAY3;

public class college {
	
		public static void main(String args[])
		{
			student rakesh=new student();
			rakesh.rollno=73;
			rakesh.name="Rakesh";
			rakesh.m1=83;
			rakesh.m2=91;
			rakesh.average();
			System.out.println(rakesh.avg);
			
			student priya=new student();
			priya.rollno=74;
			priya.name="Priya";
			priya.m1=93;
			priya.m2=41;
			priya.average();
			System.out.println(priya.avg);
			
		}
	}

