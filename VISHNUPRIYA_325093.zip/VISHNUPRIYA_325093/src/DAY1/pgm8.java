package DAY1;

public class pgm8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		System.out.println(a++);
		System.out.println(++a);
		System.out.println(a--);

	}

}
