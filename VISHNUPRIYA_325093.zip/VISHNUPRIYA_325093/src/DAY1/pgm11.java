package DAY1;

public class pgm11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=58,c=20;
		if(a>b)
		{
			if(a>c)
				{
				System.out.println(a+"is greater");
				}
			else
			{
				System.out.println(c+"is greater");
			}
			}
		else
			if(b>c)
			{
			System.out.println(b+"is greater");
	        }

}
}
