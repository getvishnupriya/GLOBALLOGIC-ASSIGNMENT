package DAY1;

public class pgm10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char name='a';
		if(name=='a'||name=='A'||name=='e'||name=='E'||name=='i'||name=='I'||name=='o'||name=='O'||name=='u'||name=='U')
		{
			System.out.println(name+ "is vowel");
		}
		else
		{
			System.out.println(name+"is not vowel");
		}
		 name='b';
		if(name=='a'||name=='A'||name=='e'||name=='E'||name=='i'||name=='I'||name=='o'||name=='O'||name=='u'||name=='U')
		{
			System.out.println(name+ "is vowel");
		}
		else
		{
			System.out.println(name+"is not vowel");
		}
		
	}

}
