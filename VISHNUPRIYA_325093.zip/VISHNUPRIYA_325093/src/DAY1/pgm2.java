package DAY1;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=128,rem=0,rev=0,t=n;
		while(n>0)
		{
		
		rem=n%10;
		rev=(rev*10)+rem;
		n=n/10;
		
		

	}
		if(rev==t)
		{
			System.out.println("it is a palindrome number");
		}
		else
		{
			System.out.println("not a palindrome number");
		}

}
}
