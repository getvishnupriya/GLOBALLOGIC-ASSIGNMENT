package DAY1;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count = 0, max_count = 10, i,sum=0;
        System.out.println("First "+max_count+" Prime Numbers:");

        for(int num=1; count<max_count; num++)
        {
            for(i=2; num%i != 0; i++);

            if(i == num)
            {
                System.out.print(" "+num);
                sum=sum+num;
                
                count++;
            }
        }
        System.out.println("\nsum is"+sum);
    }
}
