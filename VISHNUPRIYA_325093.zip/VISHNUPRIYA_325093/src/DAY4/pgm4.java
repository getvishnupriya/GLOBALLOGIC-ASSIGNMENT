package DAY4;


public class pgm4 {

    String s="i am learning java";
    int noc[]=new int[50];
    char ch_u[]=new char[20];
    int c=0;
    int i=s.length();

    public  boolean check_arr(char check)
    {
        boolean flag=false;
        for(int m=0;m<c;m++)
        {
            if(ch_u[m] == check)
            {
                flag=true;
            }
        }
        if(flag == false)
        {
            ch_u[c]=check;
            c++;
        }
        return flag;
    }


    public  void count(char val)
    {
        for(int n=0;n<c;n++)
        {
            if(ch_u[n] == val) {
                noc[n] += 1;
            }
        }

    }


    public  void display()
    {
        for(int k=0;k<c;k++)
        {
            if(ch_u[k] == ' '){
                System.out.print("White Space : ");
                System.out.println(noc[k]);
                continue;
            }
            System.out.println(ch_u[k]+":"+ noc[k]);
        }
    }


    public static void main(String a[])
    {
        pgm4 p1= new pgm4();
        int x;

        for(x=0; x<p1.i; x++)
        {
            boolean f = p1.check_arr(p1.s.charAt(x));
            p1.count(p1.s.charAt(x));
        }
        p1.display();
    }
}



