package SDAY5;

import org.testng.annotations.Test;


public class NewTest3 {
	
	
	pgm3 loginobj;
	login_data ldata,ldata_out;
	
  @Test
  public void t1() {
	  
	  ldata =new login_data();
	  ldata_out=new login_data();
	  loginobj=new pgm3();
	  
	  
	  ldata.u_id="vishnupriya3@gmail.com";
	  ldata.pwd="pass123$";
	  ldata.ex_res="SUCCESS";
	  
	  ldata_out=loginobj.login(ldata);
	  System.out.println("ldata_ac_re :"+ ldata.ac_res);
	  
	  
	  
	  
	  
  }
}
