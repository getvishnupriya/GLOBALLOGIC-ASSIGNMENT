package SDAY5;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTest1 {
	
	
	
  @Test
  public void t1() {
	  
	  System.out.println("in test t1");
  }
  
  @Test
  public void t2() {
	  
	  System.out.println("in test t2");
  }
  
  @Test
  public void t3() {
	  
	  System.out.println("in test t3");
  }
  
}
