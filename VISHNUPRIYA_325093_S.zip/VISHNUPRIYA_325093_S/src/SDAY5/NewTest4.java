package SDAY5;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTest4 {
	
	@BeforeClass
	public void t1()
	{
		System.out.println("I came to the Stadium");
	}
	
	@BeforeMethod
	public void t2()
	{
		System.out.println("Hello");	
	}
	
	@Test
	public void t3() 
	{
		System.out.println(" I met Mr.Dhoni");
	}
	
	@AfterMethod
	public void t4()
	{
		System.out.println("Bye");
	}
	
	@Test
	public void t5() 
	{
		System.out.println(" I had my lunch with Mr.Virat Kohli");
	}
	
	@Test
	public void t6() 
	{
		System.out.println(" I took a pic with Mr.Rohit Sharma");
	}
	
	@AfterClass
	public void t7()
	{
		System.out.println("Now i am back home");
	}
	
	
}
