package SDAY6;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class All_driver_methods {
 WebDriver dr;
	

	All_driver_methods(WebDriver dr) {
		
		this.dr = dr;
	}
	
	public void enter(String xp,String data)
	{
		System.out.println(xp);
		System.out.println(data);
	//	dr.findElement(By.className(xp)).sendKeys(data);
		dr.findElement(By.xpath(xp)).sendKeys(data);
		//dr.findElement(By.xpath("//*[@id=\"user-name\"]")).sendKeys("dfddsf");
	}
	
	public void click(String xp)
	{
		dr.findElement(By.xpath(xp)).click();
	}
	
	public void launchchrome(String url)
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		dr=new ChromeDriver();              
		dr.get(url);
		//dr.findElement(By.xpath("//*[@id=\"user-name\"]")).sendKeys("dfddsf");
	}
	


}
