package SDAY6;

public class login_data {
	String u_id;
	String ex_res;
	String ac_res;
	String t_res;
	String pwd;
	String ex_em1,ex_em2,ac_em1,ac_em2;
	

	
	
}
