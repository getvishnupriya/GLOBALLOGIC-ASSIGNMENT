package SDAY6;

public class login_key {
	String key;
	String loc;
	String td;

}
