package SDAY6;

import org.testng.annotations.Test;

public class NewTest1 {
  @Test(priority=0)
  public void c() {
	  System.out.println("in test c");
  }
  
  @Test(priority=1)
  public void b() {
	  System.out.println("in test b");
  }
  
  @Test(priority=2)
  public void a() {
	  System.out.println("in test a");
  }
}
