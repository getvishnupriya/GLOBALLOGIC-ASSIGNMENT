package SDAY12;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://www.facebook.com");
		
		WebElement email=dr.findElement(By.id("email"));
		WebElement pwd=dr.findElement(By.id("pass"));
		WebElement fn=dr.findElement(By.xpath(" //*[@id=\"email\"]"));
		
		email.sendKeys("noida");
		Actions kbm=new Actions(dr);
		Actions kbm1=new Actions(dr);
		
		email.sendKeys(Keys.CONTROL +"a");
		email.sendKeys(Keys.CONTROL +"c");
		
		fn.click();
		fn.sendKeys(Keys.CONTROL +"v");
		
		

	}

}
