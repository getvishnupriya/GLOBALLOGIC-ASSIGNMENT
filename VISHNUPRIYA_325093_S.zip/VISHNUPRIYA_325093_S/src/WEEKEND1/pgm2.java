package WEEKEND1;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class pgm2 {
	
	
	

	public  reg_data register(reg_data ob) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login/");
		dr.findElement(By.xpath(" /html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
		dr.findElement(By.xpath(" //*[@id=\"gender-male\"]")).click();
		dr.findElement(By.xpath(" //*[@id=\"FirstName\"]")).sendKeys(ob.f_name);
		dr.findElement(By.xpath(" //*[@id=\"LastName\"]")).sendKeys(ob.l_name);
		dr.findElement(By.xpath(" //*[@id=\"Email\"]")).sendKeys(ob.email);
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(ob.pwd);
		dr.findElement(By.xpath(" //*[@id=\"ConfirmPassword\"]")).sendKeys(ob.c_pwd);
		dr.findElement(By.xpath(" //*[@id=\"register-button\"]")).click();
		
		ob.ac_res=dr.findElement(By.xpath(" /html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		return ob;
		
	}

}
