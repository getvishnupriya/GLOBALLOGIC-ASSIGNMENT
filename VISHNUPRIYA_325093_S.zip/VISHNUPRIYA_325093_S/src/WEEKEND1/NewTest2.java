package WEEKEND1;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;



public class NewTest2 {
	pgm2 regobj;
	reg_data rdata,rdata_out;
	
	
	
  @BeforeClass
  public void config() {
	  
	  rdata=new reg_data();
	  rdata_out =new reg_data();
	  regobj=new pgm2();
	  
  }
  
  @Test(dataProvider="security")
  public void loginl(String f,String l,String e,String p,String c,String ex) {
	 // System.out.println("login  :"+u+" "+" "+p);
	  rdata.f_name=f;
	  rdata.l_name=l;
	  rdata.email=e;
	  rdata.pwd=p;
	  rdata.c_pwd=c;
	  rdata.ex_res=ex;
	 // System.out.println(rdata.ac_res);
	  rdata_out=regobj.register(rdata);
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(rdata.ac_res,rdata_out.ex_res);
	  sa.assertAll();
			  
  }
  @DataProvider (name="security")
  public  String[][] provide_data()
  
  {
	  String[][] data={{"chippi","vishnu","vishnupriya47@gmail.com","pass123$","pass123$","vishnupriya47@gmail.com"},
		{"chippi","vishnu","vishnupriya47@gmail.com","pass123$","pass123$","vishnupriya3@gmail.com"}};
	return data; 
	  
  }
}
