package SDAY11;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class pgm1 {
	
	@FindBy(xpath="//*[@id=\"email\"]")
	WebElement email;
	
	@FindBy(xpath="//*[@id=\"pass\"]")
	WebElement pass;
	
    @FindBy(xpath="//*[@id=\"u_0_2\"]")
	WebElement button;
	
    public static WebDriver dr;
	
	public void vp() {
		//vp2(dr);
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
	    dr=new ChromeDriver();              //launch the browser
		dr.get("https://www.facebook.com");       
		//dr.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("getvishnupriya@gmail.com"); 
		
		
	}
	
	public void vp2(WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr, this);
		email.sendKeys("getvishnupriya@gmail.com");
		//dr.findElement(By.xpath("//*[@id=\"pass\"]")).sendKeys("vishnu@1809!");
		
		pass.sendKeys("vishnu@1809!");
		button.click();
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		pgm1 p =new pgm1();
		    //open the url
	
		p.vp();
		p.vp2(dr);
		
	

		
		

	}

}
