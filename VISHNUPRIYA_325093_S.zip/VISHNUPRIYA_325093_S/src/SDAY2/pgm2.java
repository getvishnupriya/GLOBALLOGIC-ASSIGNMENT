package SDAY2;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();              //launch the browser
		dr.get("https://www.facebook.com");           //open the url
		
		
		WebElement we1=dr.findElement(By.xpath("//*[@id=\"day\"]"));
	Select sel1=new Select(we1);
	sel1.selectByVisibleText("18");
	
	WebElement we2=dr.findElement(By.id("month"));
		Select sel2=new Select(we2);
		sel2.selectByVisibleText("Sept");
	
	WebElement we3=dr.findElement(By.id("year"));
	Select sel3=new Select(we3);
sel3.selectByVisibleText("1997");
	
	String title=dr.getTitle();
	System.out.println("title :"+title);
	
	
	//Radio button
	List rb=dr.findElements(By.name("sex"));
	((WebElement)rb.get(0)).click();

	}

}
