package SDAY1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class first_pgm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();              //launch the browser
		dr.get("https://www.facebook.com");           //open the url
		
		
		
		
		dr.findElement(By.id("email")).sendKeys("getvishnupriya@gmail.com");
		dr.findElement(By.id("pass")).sendKeys("vishnu@1809!");
		dr.findElement(By.xpath("//*[@id=\"loginbutton\"]")).click();
		
		
		
		//Radio button
		String a_profile=dr.findElement(By.xpath("//*[@id=\"navItem_100007114564257\"]/a/div")).getText();
		//System.out.println(a_profile);
		//String b_profile="Vishnupriya";
		if( a_profile.equals("Vishnupriya Jayaraj"))
		{
			System.out.println("successful");
		}
		else
			System.out.println("Unsuccessful");
		
		
		
//		WebElement we1=dr.findElement(By.id("day"));
//		Select sel1=new Select(we1);
//		sel1.selectByVisibleText("18");
//		
//		WebElement we2=dr.findElement(By.id("month"));
//		Select sel2=new Select(we2);
//		sel2.selectByVisibleText("Sept");
//		
//		WebElement we3=dr.findElement(By.id("year"));
//		Select sel3=new Select(we3);
//		sel3.selectByVisibleText("1997");
//		
	String title=dr.getTitle();
	System.out.println("title :"+title);
//		
//		List rb=dr.findElements(By.name("sex"));
//		((WebElement)rb.get(0)).click();
		
		
		
		
		
		
		

	}

}
