package SDAY4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import SDAY4.login_data;

public class pgm3 {
	static login_data ldata;
	//static ArrayList<login_data> arr=new ArrayList<login_data>();
	
	
	public static login_data read_excel(int i)
	{
		login_data ob=new login_data();
		File f=new File("C:\\Users\\vishnupriya.jayaraj\\Desktop\\sel_pgm2.xlsx");
		try {
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			
			XSSFRow r=sh.getRow(i);
			
			XSSFCell c1=r.getCell(0);
			ob.u_id=c1.getStringCellValue();
			
			XSSFCell c2=r.getCell(1);
			ob.pwd=  c2.getStringCellValue();
			
			XSSFCell c6=r.getCell(2);
			ob.ex_res=  c6.getStringCellValue();
			
			if(ob.ex_res.equals("FAILURE"))
			{
			
			XSSFCell c4=r.getCell(3);
			ob.ex_em1=  c4.getStringCellValue();
			
			XSSFCell c5=r.getCell(4);
			ob.ex_em2=  c5.getStringCellValue();
			
			}
		}
			
			
			
			
			
			
			//System.out.println(ob.u_id);
			
			
		
			catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ldata=ob;
		return ob;
		
		
	}
	public static login_data login() {
		//ldata = new login_data();
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		System.out.println(ldata.u_id);
		dr.findElement(By.xpath("//*[@id=\"Email\"] ")).sendKeys(ldata.u_id);
		dr.findElement(By.xpath(" //*[@id=\"Password\"]")).sendKeys(ldata.pwd);
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();

		boolean f=dr.getTitle().contains("Login");
		
		if(!f)
		{
			ldata.ac_res="SUCCESS";
			//ldata.t_res="PASS";
			
		}
		else
		{
			ldata.ac_res="FAILURE";
			ldata.ac_em1=dr.findElement(By.xpath(" /html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
			System.out.println(ldata.ac_em1);
			
			//System.out.println(ldata.ac_res);
			ldata.ac_em2=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
			System.out.println(ldata.ac_em2);
		}
		
		if(ldata.ex_res.equals(" FAILURE"))
		{
		
		
			if(ldata.ac_em1.equals(ldata.ex_em1) && ldata.ac_em2.equals(ldata.ex_em2) && ldata.ac_res.equals(ldata.ex_res))
			{
				ldata.t_res="PASS";
				
			}
			else
			{
				ldata.t_res="FAIL";
			}
			
		
		
		
		}
		else {
			if(ldata.ex_res.equals(ldata.ac_res))
				ldata.t_res="PASS";
		}
		
		
		//arr.add(ldata);
		return ldata;
		
		
		
	}
	
	private static void write_excel(int i,login_data ldata) {
		// TODO Auto-generated method stub
		File f=new File("C:\\Users\\vishnupriya.jayaraj\\Desktop\\sel_pgm2.xlsx");
		FileInputStream fis;
		try {
			fis = new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			
			XSSFRow r=sh.getRow(i);
			
			XSSFCell c1=r.createCell(5);
			c1.setCellValue(ldata.ac_res);
			if(ldata.ex_res.equals("FAILURE"))
			{
			XSSFCell c2=r.createCell(6);
			c2.setCellValue(ldata.ac_em1);
			
			XSSFCell c3=r.createCell(7);
			c3.setCellValue(ldata.ac_em2);
			
			}
			
			XSSFCell c4=r.createCell(8);
			c4.setCellValue(ldata.t_res);
			
			
			
			
			
			
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
			
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ldata = new login_data();
	for(int i=1;i<=2;i++)
	{
		read_excel(i);
		login();
		write_excel(i,ldata);
	}

	}


}
