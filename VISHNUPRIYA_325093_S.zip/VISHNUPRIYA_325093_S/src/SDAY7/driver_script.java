package SDAY7;

import org.openqa.selenium.WebDriver;


public class driver_script  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String kw,loc,td;
		WebDriver dr=null;
		all_driver_methods we=new  all_driver_methods(dr);
		excel_op excel=new excel_op();
	
		for(int r=1;r<=18;r++)
		{
			
			kw=excel.read_excel(r,3);
			loc=excel.read_excel(r,4);
			td=excel.read_excel(r,5);
			//System.out.println(kw);
			switch(kw)
			{
			case "launchchrome":
				we.launchchrome(td);
				break;
				
			case "enter_txt":
				we.enter_txt(loc,td);
				break;
				
			case "click_btn":
				we.click_btn(loc);
				break;
				
			case "click_rb":
				we.click_rb(loc);
				break;
				
	    	case "verify":
			    we.verify(loc,td,r);
			   // System.out.println(loc);
		        break;
			case "close":
				we.close();
				break;
				
				
				
				
			}
		}

	}

	}
