package SDAY7;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_op {
	
	String s;
	public  String read_excel(int r1,int i)
	{
		File f=new File("C:\\Users\\vishnupriya.jayaraj\\Desktop\\excelsss\\sel_pgm1.xlsx");
		try {
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			
			XSSFRow r=sh.getRow(r1);
			XSSFCell c1=r.getCell(i);
			s=c1.getStringCellValue();
			}
			catch (Exception e) {
			e.printStackTrace();
		} 
		
		
		return s;
		
	
		
		
		
	}
	
	public void write_excel(int r2,String s)
	{
		File f=new File("C:\\Users\\vishnupriya.jayaraj\\Desktop\\excelsss\\sel_pgm1.xlsx");
		FileInputStream fis;
		try {
			fis = new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow r=sh.getRow(r2);
			XSSFCell c1=r.createCell(6);
			c1.setCellValue(s);
			
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
