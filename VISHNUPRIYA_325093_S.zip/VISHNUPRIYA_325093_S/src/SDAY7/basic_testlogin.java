package SDAY7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class basic_testlogin extends excel_io_arr {
	
	public static String login(String u_id,String pwd, String ex_res) {
		String ac_res;
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		//System.out.println(ldata.u_id);
		dr.findElement(By.xpath("//*[@id=\"Email\"] ")).sendKeys(u_id);
		dr.findElement(By.xpath(" //*[@id=\"Password\"]")).sendKeys(pwd);
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();

		boolean f=dr.getTitle().contains("Login");
		
		if(!f)
		{
			ac_res="SUCCESS";
			//ldata.t_res="PASS";
			dr.findElement(By.xpath("//a[@href='/logout']")).click();
			
		}
		else
		{
			ac_res="FAILURE";
			
		}
		
		dr.close();
		return ac_res;
		
		
		
	}

}
