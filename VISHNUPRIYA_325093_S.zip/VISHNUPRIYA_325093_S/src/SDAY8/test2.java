package SDAY8;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class test2 {

	WebDriver dr;
	@Test
	 public void beforeClass() {
		  
		  System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
			dr=new ChromeDriver();              
			dr.get("https://www.saucedemo.com/");
}
}
