package SDAY3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		//String title1=dr.findElement(By.xpath(" /html/body/div[4]/div[1]/div[4]/div[2]/div/div[1]/h1")).getText();
		
		String title=dr.getTitle();
		String actual="Demo Web Shop. Login";
		//System.out.println("title :"+title);
		if(title.equals(actual))
		{
			System.out.println("Successful Welcome Page");
		}
		else
		{
			System.out.println("Unsuccessful");
		}
		dr.findElement(By.xpath(" /html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
		String title1=dr.getTitle();
		String actual1="Demo Web Shop. Register";
		if(title1.equals(actual1))
		{
			System.out.println("Successful Registration Page");
		}
		else
		{
			System.out.println("Unsuccessful");
		}
		dr.findElement(By.xpath(" //*[@id=\"gender-male\"]")).click();
		dr.findElement(By.xpath(" //*[@id=\"FirstName\"]")).sendKeys(" Vishnu");
		dr.findElement(By.xpath(" //*[@id=\"LastName\"]")).sendKeys("Jayaraj");
		dr.findElement(By.xpath(" //*[@id=\"Email\"]")).sendKeys("vishnupriya3@gmail.com");
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("pass123$");
		dr.findElement(By.xpath(" //*[@id=\"ConfirmPassword\"]")).sendKeys("pass123$");
		dr.findElement(By.xpath(" //*[@id=\"register-button\"]")).click();
		String s=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]")).getText();
		String s2="Your registration completed";
		if(s.equals(s2))
		{
			System.out.println("sign in successfully");
		}
		else
		{
			System.out.println("Sign in unsuccessfull");
		}
		String ex=dr.findElement(By.xpath(" /html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		String actual2="vishnupriya3@gmail.com";
		if(ex.equals(actual2))
		{
			System.out.println("SUCCESS");
		}
		else
		{
			System.out.println("FAIL");
		}
	}

}
