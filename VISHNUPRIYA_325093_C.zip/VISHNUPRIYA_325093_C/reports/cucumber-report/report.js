$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("a.feature");
formatter.feature({
  "line": 1,
  "name": "AUT Login",
  "description": "",
  "id": "aut-login",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Login with valid data",
  "description": "",
  "id": "aut-login;login-with-valid-data",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "Login page is displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "User enters login data and clicks ok button",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "Home page is displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "test1.login_page_is_displayed()"
});
formatter.result({
  "duration": 8373314100,
  "status": "passed"
});
formatter.match({
  "location": "test1.user_enters_login_data_and_clicks_ok_button()"
});
formatter.result({
  "duration": 1789105101,
  "status": "passed"
});
formatter.match({
  "location": "test1.home_page_is_displayed()"
});
formatter.result({
  "duration": 1038491901,
  "status": "passed"
});
formatter.scenario({
  "line": 8,
  "name": "Login with invalid data",
  "description": "",
  "id": "aut-login;login-with-invalid-data",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 9,
  "name": "Login page is displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 10,
  "name": "User enters invalid login data and clicks ok button",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "Login is not successful",
  "keyword": "Then "
});
formatter.match({
  "location": "test1.login_page_is_displayed()"
});
formatter.result({
  "duration": 8272017100,
  "status": "passed"
});
formatter.match({
  "location": "test2.user_enters_invalid_login_data_and_clicks_ok_button()"
});
formatter.result({
  "duration": 1490106200,
  "status": "passed"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
});