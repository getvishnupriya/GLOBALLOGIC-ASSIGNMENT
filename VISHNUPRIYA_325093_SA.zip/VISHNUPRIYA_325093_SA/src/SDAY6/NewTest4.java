package SDAY6;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class NewTest4 {
  @Test(dataProvider ="security")
  public void login(String u,String p,String er) {
	  System.out.println("login  :"+u+" "+p+" "+er);
  }
  @DataProvider (name="security")
  public  String[][] getdata()
  
  {
	  String[][] data={{"u_id","pw1","er1"},
		{"u_id2","pw2","er2"}};
	return data; 
	  
  }
}
