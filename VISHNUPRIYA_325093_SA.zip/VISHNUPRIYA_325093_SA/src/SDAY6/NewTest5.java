package SDAY6;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest5 {
	pgm5 loginobj;
	login_data ldata,ldata_out;
	
	
	
  @BeforeClass
  public void config() {
	  
	  ldata=new login_data();
	  ldata_out =new login_data();
	  loginobj=new pgm5();
	  
  }
  
  @Test(dataProvider="security")
  public void loginl(String u,String p,String er) {
	  System.out.println("login  :"+u+" "+" "+p);
	  ldata.u_id=u;
	  ldata.pwd=p;
	  ldata.ex_res=er;
	  ldata_out=loginobj.login(ldata);
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(ldata_out.ac_res,ldata_out.ex_res);
	  sa.assertAll();
			  
  }
  @DataProvider (name="security")
  public  String[][] getdata()
  
  {
	  String[][] data={{"vishnupriya3@gmail.com","pass123$","SUCCESS"},
		{"vishnupriya3@gmail.com","pw2","FAILURE"}};
	return data; 
	  
  }
}
