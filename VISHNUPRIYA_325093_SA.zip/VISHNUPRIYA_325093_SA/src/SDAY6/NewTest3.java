package SDAY6;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;




public class NewTest3 {
	pgm3 loginobj;
	login_data ldata,ldata_out;
	
  @Test
  public void t1() {
	  
	  ldata =new login_data();
	  ldata_out=new login_data();
	  loginobj=new pgm3();
	  
	  
	  ldata.u_id="vishnupriya3@gmail.com";
	  ldata.pwd="pass123$";
	  ldata.ex_res="SUCCESS";
	  
	  ldata_out=loginobj.login(ldata);
	  
	  System.out.println("ldata_ac_re :"+ ldata.ac_res);
	  
	  
	  
	  
	  
  }
  
  @Test
  public void t2() {
	  
	  ldata =new login_data();
	  ldata_out=new login_data();
	  loginobj=new pgm3();
	  
	  
	  ldata.u_id="vishnupriya3@gmail.com";
	  ldata.pwd="pass123";
	  ldata.ex_res="SUCCESS";
	  
	  ldata_out=loginobj.login(ldata);
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(ldata.ac_res,ldata.ex_res);
	  sa.assertAll();
	  System.out.println("ldata_ac_re :"+ ldata.ac_res);
	  
	  
	  
	  
	  
  }
  
  
}
