package SDAY6;

import org.openqa.selenium.WebDriver;





public class driver_script1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//login_key ob1=new login_key();
		String kw,loc,td;
		
		WebDriver dr=null;
		All_driver_methods we=new  All_driver_methods(dr);
		excel_oper excel=new excel_oper();
		for(int r=1;r<=4;r++)
		{
			
			kw=excel.read_excel(r,3);
			loc=excel.read_excel(r,4);
			td=excel.read_excel(r,5);
			
			
			System.out.println(loc);
			System.out.println(kw);
			System.out.println(td);
			
			
			switch(kw)
			{
			case "launchchrome":
				System.out.println("Hello WOrld");
				we.launchchrome(td);
				break;
				
			case "enter_txt":
				System.out.println("Inside Case 2 :"+loc);
				System.out.println("Inside Case 2 :"+ td);
				we.enter(loc,td);
				break;
				
			case "click_btn":
				we.click(loc);
				break;
				
				
			}
			
			
			
		}

	}


}
