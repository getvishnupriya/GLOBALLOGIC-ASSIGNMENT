package SDAY6;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import SDAY6.login_key;

public class excel_oper {
	String s;
	public  String read_excel(int r1,int i)
	{
		//login_key ob=new login_key();
		File f=new File("C:\\Users\\vishnupriya.jayaraj\\Desktop\\sel_pgm3.xlsx");
		try {
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			
			XSSFRow r=sh.getRow(r1);
			XSSFCell c1=r.getCell(i);
			s=c1.getStringCellValue();
			}
			catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		//System.out.println(s);
		return s;
		
	
		
		
		
	}
	

}
