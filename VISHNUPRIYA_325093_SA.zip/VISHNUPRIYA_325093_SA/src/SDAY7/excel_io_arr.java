package SDAY7;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_io_arr {
	public static String[][] testdata;
	public static int rowno;
	public static void get_test_data()
	{
		File f=new  File("C:\\Users\\vishnupriya.jayaraj\\Desktop\\excelsss\\sel_pgm2.xlsx");
		try {
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow r=sh.getRow(rowno);
			XSSFCell c1=r.getCell(0);
			testdata[rowno-1][0]=c1.getStringCellValue();
			
			XSSFCell c2=r.getCell(1);
			testdata[rowno-1][1]=c2.getStringCellValue();
			
			XSSFCell c3=r.getCell(2);
			testdata[rowno-1][2]=c3.getStringCellValue();
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
