package SDAY7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class all_driver_methods  {
	
	WebDriver dr;
	String ac_res;
	excel_op excel=new excel_op();

	all_driver_methods(WebDriver dr)
	{
		
		this.dr = dr;
	}
	public void launchchrome(String url)
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		dr=new ChromeDriver();              
		dr.get(url);
		
	}
	
	public void click_btn(String xp)
	{
		dr.findElement(By.xpath(xp)).click();
	}
	
	public void click_rb(String xp)
	{
		dr.findElement(By.xpath(xp)).click();
	}
	
	public void enter_txt(String xp,String data)
	{
		dr.findElement(By.xpath(xp)).sendKeys(data);
	}
	
	public void verify(String xp,String data,int n)
	{	
		//System.out.println("hgdhc");
		ac_res=dr.findElement(By.xpath(xp)).getText();
		//System.out.println(data);
		if(ac_res.equals(data))
			excel.write_excel(n,"SUCCESS");
		else
			excel.write_excel(n,"FAILURE");
		
	}
	
	public void close()
	{
		dr.close();
	}
	

}
