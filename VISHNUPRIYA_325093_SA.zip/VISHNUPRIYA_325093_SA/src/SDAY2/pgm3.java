package SDAY2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();      
		dr.get("https://www.w3schools.com/html/html_tables.asp");
		
		int c=3,r=1;
		String s1="//*[@id=\"customers\"]/tbody/tr[" +c+ "]/td[" +r+ "]";
		String s=dr.findElement(By.xpath(s1)).getText();
		System.out.println(s);
		
	}

}
