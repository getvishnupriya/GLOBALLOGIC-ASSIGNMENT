package SDAY2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();              //launch the browser
		dr.get("https://www.facebook.com");           //open the url
		
		
		
		
		dr.findElement(By.id("email")).sendKeys("getvishnupriya@gmail.com");
		dr.findElement(By.id("pass")).sendKeys("vishnu@1809!");
		dr.findElement(By.xpath("//*[@id=\"loginbutton\"]")).click();
		

		
		String a_profile=dr.findElement(By.xpath("//*[@id=\"navItem_100007114564257\"]/a/div")).getText();
		//System.out.println(a_profile);
		//String b_profile="Vishnupriya";
		if( a_profile.equals("Vishnupriya Jayaraj"))
		{
			System.out.println("successful");
		}
		else
			System.out.println("Unsuccessful");
		

	}

}
