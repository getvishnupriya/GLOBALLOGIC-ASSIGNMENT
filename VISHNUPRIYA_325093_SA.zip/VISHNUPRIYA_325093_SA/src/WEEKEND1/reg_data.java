package WEEKEND1;

public class reg_data {
	
	String f_name;
	String l_name;
	String email;
	String pwd;
	String c_pwd;
	String ex_res;
	String ac_res;
	

}
