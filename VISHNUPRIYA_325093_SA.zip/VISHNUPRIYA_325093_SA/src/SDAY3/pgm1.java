package SDAY3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm1 {
	
	 static login_data testdata;
	
	public static login_data read_excel()
	{
		login_data ob=new login_data();
		File f=new File("C:\\Users\\vishnupriya.jayaraj\\Desktop\\sel_pgm1.xlsx");
		try {
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow r=sh.getRow(1);
			
			XSSFCell c1=r.getCell(0);
			ob.u_id=c1.getStringCellValue();
			
			XSSFCell c2=r.getCell(1);
			ob.pass= (int) c2.getNumericCellValue();
			
			
			
			//System.out.println(ob.u_id);
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ob;
		
		
	}
	
	public static void login()
	{
			System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
			WebDriver dr=new ChromeDriver();
			dr.get(" http://demowebshop.tricentis.com/login");
			
			dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(testdata.u_id);
			String p = Integer.toString(testdata.pass);
			
			dr.findElement(By.xpath(" //*[@id=\"Password\"]")).sendKeys(p);
			
			dr.findElement(By.xpath(" /html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
			String ac=dr.findElement(By.xpath(" /html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
			String fr="getvishnupriya@gmail.com";
			if(ac.equals(fr))
			{
				testdata.a_res="SUCCESS";
				testdata.t_res="PASS";
			}
			
			
	}
	

	private static void write_excel() {
		// TODO Auto-generated method stub
		File f=new File("C:\\Users\\vishnupriya.jayaraj\\Desktop\\sel_pgm1.xlsx");
		FileInputStream fis;
		try {
			fis = new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			
			XSSFRow r=sh.getRow(1);
			
			XSSFCell c1=r.createCell(3);
			c1.setCellValue(testdata.a_res);
			
			XSSFCell c2=r.createCell(4);
			c2.setCellValue(testdata.t_res);
			
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
			
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		testdata = new login_data();
		testdata = read_excel();
		login();
		write_excel();
		

	}

}
