package SDAY3;

public class login_data {
	
	String u_id,e_res,a_res,t_res;
	int pass;

}
