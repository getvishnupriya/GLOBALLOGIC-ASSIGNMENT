package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;


import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test2 {
	
	WebDriver dr;
	
	
	
	@When("^User enters invalid login data and clicks ok button$")
	public void user_enters_invalid_login_data_and_clicks_ok_button() throws Throwable {
		dr=test1.dr;
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		dr.findElement(By.xpath("//*[@id=\"Email\"] ")).sendKeys("vishnupriyaa@gmail.com");
		dr.findElement(By.xpath(" //*[@id=\"Password\"]")).sendKeys("pass123$");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();	
		

}
	
	@Then("^Login is not successfull$")
	public void Login_is_not_successfull() throws Throwable {
			String ex_res="Register";
			String ac_res=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
			SoftAssert sa=new SoftAssert();
			sa.assertEquals(ac_res,ex_res);
			sa.assertAll();
		
	}
}
